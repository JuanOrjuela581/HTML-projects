<?php include("src/includes/header.php") ?>

<section class="principal">
    <div class="contenido">
        <h1>Contamos Con La Mejor Calidad y Servicio Del Pais</h1>
        <br/>
        <br/>
        <br/>
        <p>Óptica visión, más que un sentido, es una familia que disfruta recorrer el camino, que ve más allá de lo distinto. </p>

        <a href="src\views\AboutUs\aboutUs.php"> <button  >
        Conocenos
    </button></a>
        
    </div>
    
    
</section>

<?php include("src/includes/footer.php") ?>



