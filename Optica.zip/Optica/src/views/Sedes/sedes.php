<?php include("../../includes/header2.php") ?>

<div class="bienvenida">
    <h1 class="titulo-sedes">Nuestras Sedes</h1>
    <a href="..\..\..\src\views\AtencionUsuario\AtencionUsuario.php">
    <button onclick="location.href='src\views\AboutUs\AboutUs.php'" class="boton-opticitas">
        Atencion al usuario
    </button>
    </a>
    

</div>

<div class="contenido-sedes">
    <h2 class="tittle-Casanare">Casanare</h2>
    <img class="image-casanare" src="..\..\..\src\images\imagen_casanare.png" alt="" width="488px" height="386px">
    <ul class="lista-casanare">
        <br />
        <li>Paz de Ariporo</li>
        <li>Villanueva</li>
        <li>Yopal</li>
    </ul>

    <h2 class="tittle-Cundinamarca">Cundinamarca</h2>
    <img class="image-cundinamarca" src="..\..\..\src\images\imagen_cundinamarca.png" alt="" width="495px" height="362px">
    <ul class="lista-cundinamarca">
        <br />
        <li>Bogotá</li>
        <li>Madrid</li>
    </ul>

    <h2 class="tittle-santander">Santander</h2>
    <img class="image-santander" src="..\..\..\src\images\imagen_santander.png" alt="" width="488px" height="386px">
    <ul class="lista-santander">
        <br />
        <li>Barbosa</li>
    </ul>

    <h2 class="tittle-boyaca">Boyacá</h2>
    <img class="image-boyaca" src="..\..\..\src\images\imagen_boyaca.png" alt="" width="492px" height="386px">
    <ul class="lista-boyaca">
        <br />
        <li>Chiquinquira</li>
        <li>Duitama</li>
        <li>Sogamoso</li>
        <li>Tunja</li>
    </ul>

    <h2 class="tittle-arauca">Arauca</h2>
    <img class="image-arauca" src="..\..\..\src\images\imagen_arauca.png" alt="" width="488px" height="386px">
    <ul class="lista-arauca">
        <br />
        <li>Arauca</li>
        <li>Tame</li>
        <li>Saravena</li>
    </ul>
</div>

<?php include("../../includes/footersedes.php") ?>