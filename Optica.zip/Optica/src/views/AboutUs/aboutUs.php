
<?php include("../../includes/header2.php") ?>

    <div class="bienvenida">
        <div class="elipse"></div>
        <h1 class="titulo-bienvenida">Acerca de Nosotros</h1>

        <a href="..\..\..\src\views\Opticitas\Opticitas.php"> <button onclick="location.href='src\views\AboutUs\AboutUs.php'" class="boton-opticitas">
            Continuar a Opticitas
        </button> </a>
        
        
    </div>
    <div class="bienvenido-container">

        <h2 class="titulo1">Bienvenido</h2>
        <p class="parrafo1">¿Qué es mejor? ¿Hacer las cosas bien o hacer lo correcto? ¿Hacer eso en lo que crees o intentar creer en lo que se hace?
            A lo largo de mi vida he aprendido que el mundo gira y cada experiencia cincela, por lo que valoro la importancia de servir. He enfrentado cada reto como una oportunidad y comprendí que la clave no está en fijar metas, cronometrar el tiempo, ni en la disciplina o en la pasión; la clave está en la debida proporción para unir todo lo que somos.
            Optisalud, más que un sentido, es una familia que disfruta recorrer el camino, que ve más allá de lo distinto. Ver para creer son milagros que descubrimos día a día de la mano con la tecnología, servicio, conocimiento. Son más que palabras, son hechos.
        </p>



        <img src="../../images/Imagen_bienvenido.jpg" class="imagen1" width="574px" height="415px"/>

        <h2 class="titulo2">Historia</h2>
        <p class="parrafo2">Optisalud es una empresa creada en 1991, de carácter familiar, desde su inicio estableció como modelo de negocio el servicio integral de oftalmología y optometría, donde las dos disciplinas se complementaron privilegiando como premisa fundamental la salud visual y ocular de los usuarios.
            Su vertiginoso desarrollo se dio inicialmente en Casanare y diez años después ingreso al mercado de Bogotá, Boyacá, Santander y Cundinamarca secuencialmente. Actualmente cuenta con dos sedes de alta complejidad en Yopal y Tunja y un centro de referencia en Bogotá, así como 17 puntos de atención complementarios en los cuatro departamentos.
            Alcanzado un posicionamiento y liderazgo en Casanare, que se comporta en el sector como un actor reconocido, con el manejo exclusivo cercano al 90% de la cobertura de aseguramiento y una importante preferencia del cliente particular, que ahora identifica como idónea la atención especializada en la región, se propone alcanzar la misma posición en Boyacá donde tiene un crecimiento sostenido desde 2015. Para el año 2022 se propone hacer una expansión en dos departamentos, Santander y Cundinamarca.
        </p>

        <img src="../../images/Imagen_historia.jpg" class="imagen2" width="758px" height="808px"/>

        <p class="parrafo3">Para el año 2025 espera consolidarse como la mejor IPS en salud visual de Colombia y hacer una expansión importante en otras especialidades, es así como actualmente está asumiendo el reto de responder a otro servicio que demanda la región en atención domiciliaria y terapia física y rehabilitación, con lo cual está haciendo una ampliación de su radio de acción bajo el mismo modelo, pero con otras áreas de salud. Actualmente Optisalud cuenta con más de 350 colaboradores lo cual nos permite hacer un ejercicio de responsabilidad social que solo nos motiva a continuar con más empeño.
        </p>

    </div>

    <div class="mision-container">
    <h2 class="titulo3">Mision</h2>
    <p class="parrafo4">Contribuir en la calidad de vida de nuestros usuarios resolviéndoles el 100% de sus problemas visuales y oculares.</p>
    </div>

    <div class="vision-container">
    <h2 class="titulo4">Vision</h2>
    <p class="parrafo5">En el 2021 habremos incrementado nuestra cobertura a un millón seiscientos mil usuarios a través de la expansión e implementación de estrategias de negocio que involucren la investigación, promoción y prevención; manteniendo así, la rentabilidad y nuestro liderazgo hoy reconocido en la región.</p>
    <img src="../../images/image_vision.jpg" class="imagen3" width="362px" height="px"/>
</div>


<div class="Corporativo-container">
    <h2 class="titulo5">Corporativo</h2>
    <p class="parrafo6">Para el 2020 esperamos dar cobertura a nuestros servicios, a cerca de un millón de colombianos, trabajando en la aplicación de estándares de calidad propios de la industria, que aseguren tratamientos efectivos y que garanticen el valor del servicio humano hacia los pacientes, para seguir siendo líderes de servicios integrales de salud visual en el país.</p>
    </div>

    <div class="Principios-container">
    <h2 class="titulo6">Principios Corporativos</h2>
    <p class="parrafo7">Más que un servicio exigente en salud visual, un servicio amigable. Es un estilo de vida basado en el compromiso, en generar valor al ser humano, en ofrecer la oportunidad de crecer con cada paciente, de generar bienestar y obtener el beneficio de hacer un trabajo impecable, lo que inspira a cada uno de ellos a dar lo mejor de sí, con cada paciente.</p>
    <img src="../../images/image_principios.jpg" class="imagen4" width="362px" height="370px"/>
</div>






<?php include("../../includes/footer2.php") ?>