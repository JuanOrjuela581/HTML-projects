<footer class="footer-sedes">
    <div class="enlaces-footer2">
        <h3 class="enlaces-titulo-footer2">Compañia</h3>
        <ul>
        <li><a href="..\..\..\index.php" class="active">Inicio</a></li>
        <li><a href="..\..\..\src\views\AboutUs\AboutUs.php">Acerca de Nosotros</a></li>
        <li><a href="..\..\..\src\views\Opticitas\Opticitas.php">Opticitas</a></li>
        <li><a href="..\..\..\src\views\Servicios\servicios.php">Servicios</a></li>
        <li><a href="..\..\..\src\views\Sedes\sedes.php">Sedes</a></li>
        </ul>


        
    </div>

    <div class="iconos-container-footer2">
    <h3 class="iconos-titulo-footer2">Siguenos</h3>
       <br>
        <a href="https://www.facebook.com" class="icono" target="blank"> <img src="..\..\images\facebook.png" alt="logo" width="50" height="50px"></a>
        <a href="https://www.instagram.com" class="icono" target="blank"> <img src="..\..\images\instagram.png" alt="logo" width="50" height="50px"></a>
    </div>

    <div class="info-container-footer2">
    <img src="..\..\..\src\images\logo-footer.png" width="244px" height="198px" class="logo-footer-footer2">
        <span>C.c. Unicentro L-1040 Remansos De Sta Inés</span>
        <br>
        <br>
        <span>© Optica visión SAS 2022.</span>



    </div>

    <div class="contactenos-footer2">
    <h3 class="iconos-titulo-footer2">Contactanos</h3>
        <span class="contacto-footer2">opticavisionintegral@siau.com</span>
    </div>
</footer>

</body>
</html>