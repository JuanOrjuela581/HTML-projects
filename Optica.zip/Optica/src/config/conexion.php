<?php
    $conn = mysqli_connect(
        'localhost',
        'root',
        '',
        'db_optica'
    );

     /*Validación conexión*/
    /*if(isset($conn)){
        echo "Conexión exitosa a la Base de Datos. Lo logramos :)";
    }*/
    
?>